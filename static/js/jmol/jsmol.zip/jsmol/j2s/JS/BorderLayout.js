Clazz.declarePackage ("JS");
Clazz.load (["JS.LayoutManager"], "JS.BorderLayout", null, function () {
c$ = Clazz.declareType (JS, "BorderLayout", JS.LayoutManager);
Clazz.defineStatics (c$,
"CENTER", "Center",
"NORTH", "North",
"SOUTH", "South",
"EAST", "East",
"WEST", "West");
});
